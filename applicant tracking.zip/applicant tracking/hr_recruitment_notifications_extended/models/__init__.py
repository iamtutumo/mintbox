# -*- coding: utf-8 -*-

from . import hr_recruitment_stage
from . import hr_applicant
